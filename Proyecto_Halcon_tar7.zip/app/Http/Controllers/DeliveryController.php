<?php
class DeliveryController extends Controller { /* deliveries */ }