<?php
class UserController extends Controller { /* CRUD users */ }