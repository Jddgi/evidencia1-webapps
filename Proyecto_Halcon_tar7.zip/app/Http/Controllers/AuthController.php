<?php
class AuthController extends Controller { /* login logout */ }