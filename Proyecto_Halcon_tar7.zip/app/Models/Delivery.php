<?php
class Delivery extends Model {}