<?php
Route::post("/login", [AuthController::class, "login"]);
Route::post("/logout", [AuthController::class, "logout"]);
Route::apiResource("users", UserController::class);
Route::apiResource("deliveries", DeliveryController::class);
Route::post("deliveries/confirm", [DeliveryController::class,"confirmDelivery"]);